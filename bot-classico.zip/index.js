const Discord = require("discord.js");
const moment = require('moment')
const config = require("./config.json");
const snekfetch = require('snekfetch');
var cor = "#7D26CD"
const db = require("quick.db")
const ms = require("ms");
const fs = require("fs");
const client = new Discord.Client()
client.prefix = config.prefix;

client.on("guildMemberAdd", async (member) => { 

    let guild = await client.guilds.cache.get("765240194643001355");
    let channel = await client.channels.cache.get("792125373616750612");

    let embed = new Discord.MessageEmbed()
    .setDescription(`**<a:lu_pig:774481433040519178>  ${member.user.username} Seja Bem vindo (a). \<a:lu_pig:774481433040519178>

> <a:NeonchatLH:771145008228728852> *• Passe no chat <#792125307628945408> para evitar punições.
> <a:NeonchatLH:771145008228728852> • Vá até o chat <#792125342986272789> e receba algumas tags especiais.*
    
<a:triangulo1LH:768656509680615435> Divirta-se na** ${member.guild.name}`)
    .setColor(cor);
    channel.send(embed).then(msgd => msgd.delete({timeout: 50000}))
    member.roles.add("792125278389928007"); // Member role.
  })
  
  client.on("guildMemberAdd", async (member) => { 

    let guild = await client.guilds.cache.get("765240194643001355");
    let channel = await client.channels.cache.get("813283343692595231");
    channel.send(`**${member.user} | ${member.user.tag} - Entrou no servidor (\`LOGS\`)**`)
    member.roles.add("792125278389928007"); // Member role.
  })
  
  client.on("guildMemberRemove", async (member) => { 

    let guild = await client.guilds.cache.get("765240194643001355");
    let channel = await client.channels.cache.get("813283440220307487");
    channel.send(`**${member.user} | ${member.user.tag} - Saiu do servidor (\`LOGS\`)**`)
    member.roles.add("792125278389928007"); // Member role.
  })
  
client.on("voiceStateUpdate", async (newState) => {
    setInterval(() => {
        if (newState.member.voice.channel && newState.member.voice.mute == false && newState.member.roles.cache.get("792125232089530400")) {
            db.add(`s_${newState.member.id}`, 1)
            if (db.fetch(`s_${newState.member.id}`) == 60) {
                db.delete(`s_${newState.member.id}`)
                db.add(`m_${newState.member.id}`, 1)
            }
            if (db.fetch(`m_${newState.member.id}`) == 60) {
                db.delete(`m_${newState.member.id}`)
                db.add(`h_${newState.member.id}`, 1)
            }
            if (db.fetch(`h_${newState.member.id}`) == 24) {
                db.add(`h_${newState.member.id}`, 1)
            }
        }
    }, 10000)
  })

client.on("message", async message => {
    if(message.author.bot) return;
    if(message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)){
let embed = new Discord.MessageEmbed()
.setColor('RANDOM')
.setDescription(`**Estou na versão v2.0
Meu prefixo é ( lh! )
Desenvolvido para 🍷 Love House 🍷**`)
        return message.reply(embed)}
    if(!message.content.startsWith(config.prefix)) return;

let args = message.content.split(" ").slice(1);
let command = message.content.split(" ")[0];
command = command.slice(config.prefix.length);
  try {
      let commandFile = require(`./commands/${command}.js`);
      delete require.cache[require.resolve(`./commands/${command}.js`)];
      return commandFile.run(client, message, args);
  } catch (err) {
        console.error("Erro:" + err)
  }
})
  
client.on("ready", () => {
    let activities = [
        `Estamos como -> ( ${client.users.cache.size} ) Isuários!.`,
        `Love House No Topo -> Está com dúvidas? Use lh!ajuda.`
    ],
        i = 0;
    setInterval(() => client.user.setActivity(`${activities[i++ % activities.length]}`, {
        type: "PLAYING", 
    }), 5000);  // WATCHING, LISTENING, PLAYING, STREAMING
    console.log("Estou Online!")
}) 


client.on("message", async message => {

    if(message.author.bot) return;
    if(message.channel.type === "dm") return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
  const comando = args.shift().toLowerCase();
  
    if(comando === "registros") {
    if (!message.member.roles.cache.has("792125228343885854")) return message.reply("Você precisa do cargo Registrador, para verificar seus registros.")
    const Registros = new Discord.MessageEmbed()
        .setColor("#00FFFF")
        .setDescription(`<:users4:785623501007486996> Staff: ${message.author}
<:Setabdg:775546719705366538> Você possuí **${(db.fetch(`registros_${message.author.id}`) + 1).toLocaleString()}** Registros
<:Setabdg:775546719705366538> Você já expulsou **${(db.fetch(`kick_${message.author.id}`) + 1).toLocaleString()}** Usuários 
<:Setabdg:775546719705366538> Você já Baniu **${(db.fetch(`ban_${message.author.id}`) + 1).toLocaleString()}** Usuários`)
        .setFooter(`ID: ${message.author.id}`)
        message.channel.send(Registros)
        message.delete().catch(O_o => {});
  };

  if(comando === "registrar") {
    if (!message.member.roles.cache.has("792125228343885854")) return message.reply("**Você precisa do cargo Registrador, para fazer registros!**").then(msgd => msgd.delete({timeout: 50000}))
    if (!message.mentions.users.first()) return message.reply("**Mencione um usuário!**").then(msgd => msgd.delete({timeout: 50000}))
    let cargos = []
    let pv = []
    let homem = message.guild.roles.cache.get("792125252578705468")
    let mulher = message.guild.roles.cache.get("792125251323428885")
    let nBinário = message.guild.roles.cache.get("792125253639733278")
    let mais18 = message.guild.roles.cache.get("792125255563870239")
    let menos18 = message.guild.roles.cache.get("792125256587280455")
    let hetero = message.guild.roles.cache.get("792125258424778772")
    let lgbt = message.guild.roles.cache.get("792125259477680160")
    let solteiro = message.guild.roles.cache.get("792125261327106060")
    let namorando = message.guild.roles.cache.get("792125264653975573")
    let casado = message.guild.roles.cache.get("792125263721922620")
    let enrolado = message.guild.roles.cache.get("792125262710964224")
    let sudeste = message.guild.roles.cache.get("792125269884272660")
    let norte = message.guild.roles.cache.get("792125266675105813")
    let sul = message.guild.roles.cache.get("792125271037706270")
    let centrooeste = message.guild.roles.cache.get("792125268881047552")
    let nordeste = message.guild.roles.cache.get("792125267752910848")
    let estrangeiro = message.guild.roles.cache.get("792125272152342608")
    let member = message.guild.member(message.mentions.users.first())
    message.delete().catch(O_o => {});
    const rEmbed1 = new Discord.MessageEmbed()
    .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
    .addField("Qual a sua sexualidade?", `1️⃣ ${homem}
2️⃣ ${mulher}
3️⃣ ${nBinário}`)
    .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", "Nenhum")
    .setColor("RANDOM")
    .setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
    const r1 = await message.channel.send(rEmbed1)
    const emojis = [ "❌", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "➡️"]
    for (const i in emojis) {
        await r1.react(emojis[i])
    }
    const filter = (r, u) => r.me && u.equals(message.author),
    collector = r1.createReactionCollector(filter, {max: 1})

    collector.on("collect", (r) => {
        switch (r.emoji.name) {
            case "1️⃣": {
                member.roles.add(homem)
                cargos.push(homem)
                pv.push(homem.name)
                r.users.remove(message.author)
                break
            }
            case "2️⃣": {
                member.roles.add(mulher)
                cargos.push(mulher)
                pv.push(mulher.name)
                r.users.remove(message.author)
                break
            }
            case "3️⃣": {
                member.roles.add(nBinário)
                cargos.push(nBinário)
                pv.push(nBinário.name)
                r.users.remove(message.author)
                break
            }
            case "➡️": {
                r.users.remove(message.author)
                r1.delete()
                if(cargos.length === 0) return message.channel.send("Essa pergunta é obrigatória! Registro cancelado!") 
                break;
            }
        }
        const r2Embed = new Discord.MessageEmbed()
        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694>
 Registrado: ${member.user}`)
.addField("Qual sua idade?", `1️⃣ ${mais18}
2️⃣ ${menos18}`)
.addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
.setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
.setColor("RANDOM")
collector.on("end", async c => {
let r2 = await r1.edit(r2Embed)
const collector2 = r2.createReactionCollector(filter, {max: 1})
collector2.on("collect", (u) => {
switch (u.emoji.name) {
    case "1️⃣": {
        member.roles.add(mais18)
        cargos.push(mais18)
        pv.push(mais18.name)
        u.users.remove(message.author)
        break
    }
    case "2️⃣": {
        member.roles.add(menos18)
        cargos.push(menos18)
        pv.push(menos18.name)
        u.users.remove(message.author)
        break
    }
    case "➡️": {
        u.users.remove(message.author)
        r2.delete()
        if (cargos.length == 1) return message.channel.send("Essa pergunta é obrigatória! Registro cancelado!").then(msgd => msgd.delete({timeout: 30000}))
        break
    }
    case "❌": {
        u.users.remove(message.author)
        r2.delete()
        member.roles.remove(homem)
        member.roles.remove(mulher)
        member.roles.remove(nBinário)
        member.roles.remove(mais18)
        member.roles.remove(menos18)
        return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
        break
    }
}
const rEmbed3 = new Discord.MessageEmbed()
.setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
.addField("Qual seu gênero?", `1️⃣ ${hetero}
2️⃣ ${lgbt}`)
.addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
.setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
.setColor("RANDOM")
collector2.on("end", async d => {
    const r3 = await r2.edit(rEmbed3)
    const collector3 = r3.createReactionCollector(filter, {max: 1})
    collector3.on("collect", (a) => {
        switch (a.emoji.name) {
            case "1️⃣": {
                member.roles.add(hetero)
                cargos.push(hetero)
                pv.push(hetero.name)
                a.users.remove(message.author)
                break
            }
            case "2️⃣": {
                member.roles.add(lgbt)
                cargos.push(lgbt)
                pv.push(lgbt.name)
                a.users.remove(message.author)
                break
            }
            case "➡️": {
                a.users.remove(message.author)
                break
            }
            case "❌": {
                u.users.remove(message.author)
                r3.delete()
                member.roles.remove(homem)
                member.roles.remove(mulher)
                member.roles.remove(nBinário)
                member.roles.remove(mais18)
                member.roles.remove(menos18)
                member.roles.remove(hetero)
                member.roles.remove(lgbt)
                return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
                break
            }
        }
        const rEmbed4 = new Discord.MessageEmbed()
        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
        .addField("Qual seu estado civíl?", `1️⃣ ${namorando}
2️⃣ ${solteiro}
3️⃣ ${casado}
4️⃣ ${enrolado}`)
        .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
        .setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
        .setColor("RANDOM")
        collector3.on("end", async k => {
            const r4 = await r3.edit(rEmbed4)
            const collector4 = r4.createReactionCollector(filter, {max: 1})
            collector4.on("collect", g => {
                switch (g.emoji.name) {
                    case "1️⃣": {
                        member.roles.add(namorando)
                        cargos.push(namorando)
                        pv.push(namorando.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "2️⃣": {
                        member.roles.add(solteiro)
                        cargos.push(solteiro)
                        pv.push(solteiro.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "3️⃣": {
                        member.roles.add(casado)
                        cargos.push(casado)
                        pv.push(casado.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "4️⃣": {
                        member.roles.add(enrolado)
                        cargos.push(enrolado)
                        pv.push(enrolado.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "➡️": {
                        g.users.remove(message.author)
                        break
                    }
                        case "❌": {
                            u.users.remove(message.author)
                            r4.delete()
                            member.roles.remove(homem)
                            member.roles.remove(mulher)
                            member.roles.remove(nBinário)
                            member.roles.remove(mais18)
                            member.roles.remove(menos18)
                            member.roles.remove(hetero)
                            member.roles.remove(lgbt)
                            member.roles.remove(enrolado)
                            member.roles.remove(casado)
                            member.roles.remove(solteiro)
                            member.roles.remove(namorando)
                            return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
                            break
                    }
                }
                const rEmbed5 = new Discord.MessageEmbed()
                .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
                .addField("Qual a sua localização?", `1️⃣ ${norte}
2️⃣ ${nordeste}
3️⃣ ${centrooeste}
4️⃣ ${sudeste}
5️⃣ ${sul}
6️⃣ ${estrangeiro}`)
                .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
                .setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
                .setColor("RANDOM")
                collector4.on("end", async (a) => {
                    const r5 = await r4.edit(rEmbed5)
                    const collector5 = r5.createReactionCollector(filter, {max: 1})
                    collector5.on("collect", k => {
                        switch (k.emoji.name) {
                            case "1️⃣": {
                                member.roles.add(norte)
                                cargos.push(norte)
                                pv.push(norte.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "2️⃣": {
                                member.roles.add(nordeste)
                                cargos.push(nordeste)
                                pv.push(nordeste.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "3️⃣": {
                                member.roles.add(centrooeste)
                                cargos.push(centrooeste)
                                pv.push(centrooeste.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "4️⃣": {
                                member.roles.add(sudeste)
                                cargos.push(sudeste)
                                pv.push(sudeste.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "5️⃣": {
                                member.roles.add(sul)
                                cargos.push(sul)
                                pv.push(sul.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "6️⃣": {
                                member.roles.add(estrangeiro)
                                cargos.push(estrangeiro)
                                pv.push(estrangeiro.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "➡️": {
                                k.users.remove(message.author)
                                break
                            }
                            case "❌": {
                                u.users.remove(message.author)
                                r4.delete()
                                member.roles.remove(homem)
                                member.roles.remove(mulher)
                                member.roles.remove(nBinário)
                                member.roles.remove(mais18)
                                member.roles.remove(menos18)
                                member.roles.remove(hetero)
                                member.roles.remove(lgbt)
                                member.roles.remove(enrolado)
                                member.roles.remove(casado)
                                member.roles.remove(solteiro)
                                member.roles.remove(namorando)
                                member.roles.remove(norte)
                                member.roles.remove(nordeste)
                                member.roles.remove(centrooeste)
                                member.roles.remove(sudeste)
                                member.roles.remove(sul)
                                member.roles.remove(estrangeiro)
                                return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
                                break
                        }
                        }
                        const embed = new Discord.MessageEmbed()
                        .setTitle(`${member.user.tag} foi registrado!`)
                        .setThumbnail(message.guild.iconURL({dynamic: true}))
                        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
                        .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", pv.join(", "))
                        .setColor("RANDOM")
                        .setFooter(`ID: ${message.author.id}`)
                        .setTimestamp()
                        const embed2 = new Discord.MessageEmbed()
                        .setTitle("Registro efetuado!")
                        .setColor("RANDOM")
                        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
                        .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
                        .setThumbnail(message.guild.iconURL({dynamic: true}))
                        .setFooter(`${message.author.tag} já fez ${(db.fetch(`registros_${message.author.id}`) + 1).toLocaleString()} registros!`)
                        collector5.on("end", async feijoada => {
                            let msg = await r5.edit(embed2)
                            client.channels.cache.get("792125345175306261").send(embed2)
                            db.add(`registros_${message.author.id}`, 1)
                            msg.delete({timeout: 10000})
                            member.roles.remove("792125278389928007")
                            member.roles.add("792125279786762240")
                            member.user.send(embed)
                            message.channel.messages.fetch({limit: 50}).then(messages => {
                                message.channel.bulkDelete(messages.filter(msg => msg.author.id == member.user.id))
                            })
                        })
                    })
                })
            })
        })
    })
})
})
    })
    })
  }
})


client.on("message",msg => {
    if(msg.content == "flynez Feio"){
        return msg.reply("**Concordo**!")
    }
});

client.on("ready", () => {
 var content = {
     embed: {
       description: "**<:LHcoree:771143613144760320> • Oi você está lindo (a) hoje, já deu boost? <#792125314515861584>**",
       color: "#7D26CD"
      }
  }
  var channel = client.guilds.cache
    .get("765240194643001355") // Id do Servidor
    .channels.cache.get("792125373616750612"); //Id do canal onde a mensagem será enviada
  setInterval(function() {
    channel.send(content).then(msgd => msgd.delete({timeout: 50000}))
  }, 3000000); 
  channel.send(content).then(msgd => msgd.delete({timeout: 50000}))
  console.log("Timer Registrar-se & Staff");
});

client.login(config.token);