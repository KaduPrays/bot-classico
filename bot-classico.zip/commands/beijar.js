const Discord = require("discord.js");

exports.run = async (client, message, args) => {

    var list = [
        "https://i.imgur.com/UhuJ2AR.gif",
        "https://i.imgur.com/Ry9EOVm.gif",
        "https://i.imgur.com/UDiss2w.gif",
        "https://i.imgur.com/1aXM0UG.gif",
        "https://loritta.website/assets/img/actions/kiss/male_x_female/gif_288.gif",,
        "https://loritta.website/assets/img/actions/kiss/female_x_female/gif_350.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802033804830048304/1ad6e80ab78961370aea61bfe56ed5a3.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802033810610454568/28ffce7409b7d8df1dfc14f288a3566f.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802033812263010334/200.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802033833763012608/tenor.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802033838179483768/tumblr_me67nj80tz1rv195co1_400.gif"

    ];

    var rand = list[Math.floor(Math.random() * list.length)];
    let user = message.mentions.users.first() ||
    client.users.cache.get(args[0]);
    if (!user) {
        return message.reply("Mencione um usuário válido.");
    }
    let avatar = message.author.displayAvatarURL({format: 'png'});
    const kiss = new Discord.MessageEmbed()
    .setColor("#FF1493")
    .setDescription(`<a:azul_beijocdh:779870264367775744> ${message.author} **Beijou** ${user}`)
    .setImage(rand)
    .setTimestamp()
    .setFooter(`ID: ${message.author.id}`)
    .setAuthor(message.author.tag, avatar)
    message.delete().catch(O_o => {});
    await message.channel.send(kiss);
}