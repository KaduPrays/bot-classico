﻿const Discord = require('discord.js')

 module.exports = {
     run: (client, message, args) => {
    if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.channel.send("**<a:erradocdh:777769043309363241> | Você não possuí permissão.**");
  let user =
    message.mentions.members.first() ||
    message.guild.members.cache.get(args[0]);
  if (!user)
    return message.channel.send(
      `<a:erradocdh:777769043309363241> **| Você não mencionou um usuário ou forneceu um id inválido**`
    );
  if (!args.slice(1).join(" "))
    return message.channel.send("<a:erradocdh:777769043309363241> **| Você não especificou sua mensagem**");
  user.user
    .send(args.slice(1).join(" "))
    .catch(() => message.channel.send("<a:erradocdh:777769043309363241> **| Esse usuário está com a DM fechada!**"))
    .then(() => message.channel.send(`Enviei uma mensagem para ${user.user.tag}`));
    message.delete().catch(O_o => {});
},
};