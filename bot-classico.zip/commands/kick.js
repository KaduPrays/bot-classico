const Discord = require('discord.js')
const db = require("quick.db")

module.exports.run = async (client, message, args) => {
    if(!message.member.hasPermission('KICK_MEMBERS')) return message.reply("Você não pode executar este comando.")
  message.delete().catch(O_o => {});
    let member = message.mentions.members.first()
    if(!member) return message.reply("**Por favor mencione um usuário válido !**")
  message.delete().catch(O_o => {});
    if(!member.kickable) return message.reply("**Eu não posso kickar esse usuário, ele possuí algum cargo maior que o meu.**")
  message.delete().catch(O_o => {});
    let reason = args.slice(1).join(' ')
    if(!reason) reason = "**Nenhum Motivo Especificado**"
      const pEmbed = new Discord.MessageEmbed()
          .setDescription(`<a:Az_StaffCDH:785623299333292102> **__Moderador:__**
${message.author.tag} 

<:users4:785623501007486996> **__Usuário:__**
${member.user.tag}

🆔 **__ID do usuário:__**
${member.user.id}

<a:livroCDH:762798356824850443> **__Motivo:__**
${reason}`)
          .setFooter(` ${message.author.tag} já expulsou ${(db.fetch(`kick_${message.author.id}`) + 1).toLocaleString()} usuários`)
          .setColor("00FFFF").setTimestamp()
          .setThumbnail(member.user.displayAvatarURL( {dynamic: true, size: 1024} ));

    let embed = new Discord.MessageEmbed()
           .setDescription(`**<@${message.author.id}>\nVocê Realmente Deseja Kickar O \n👤Usuário(a): <@${member.user.id}>?**`)
           .setColor('#00FA9A')

return message.channel.send(embed).then(msg => {
        msg.react('✅');
        msg.react('❌');
        const FilterYes = (reaction, user) => {
            return reaction.emoji.name === '✅' && user.id === message.author.id;
        };
        
        const CollectorYes = msg.createReactionCollector(FilterYes, { time: 60000, max: 1 });
        
        CollectorYes.on('collect', (reaction, user) => {
            member.kick(reason)
            message.channel.send(pEmbed)
            msg.delete()
         })

            const FilterCancel = (reaction, user) => {
                return reaction.emoji.name === '❌' && user.id === message.author.id;
            };


                const CollectorCancel = msg.createReactionCollector(FilterCancel, { time: 60000, max: 1 });
                CollectorCancel.on('collect', (reaction, user) => {
                    message.channel.send('**O Comando Foi Cancelado.**').then(msgd => msgd.delete({timeout: 10000}))
                    msg.delete()
   })
 })
}