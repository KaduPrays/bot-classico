const Discord = require("discord.js");

exports.run = async (client, message, args) => {
message.delete();
const content = args.join(" ");

if (!args[0]) {
  return message.channel.send(`${message.author.username}, **Escreva a sugestão após o comando**`).then(msgd => msgd.delete({timeout: 15000}))
message.delete().catch(O_o => {});
} else if (content.length > 1000) {
  return message.channel.send(`${message.author.username}, **Forneça uma sugestão de no máximo 1000 caracteres.**`).then(msgd => msgd.delete({timeout: 15000}));
message.delete().catch(O_o => {});
} else {
  var canal = message.guild.channels.cache.find(ch => ch.id === "786096970015047710");
  const msg = await canal.send(
    new Discord.MessageEmbed()
    .setColor("RANDOM")
    .addField("<:pessoaCDH:775865182982897694> Autor:", message.author)
    .addField("<a:livroCDH:762798356824850443> Conteúdo", content)
    .setFooter("ID do Autor: " + message.author.id)
    .setTimestamp()
  );

  const emojis = ["<a:certocdh:783522736932126730>", "<a:erradocdh:777769043309363241>"];

  for (const i in emojis) {
message.delete().catch(O_o => {});
    await msg.react(emojis[i])
  }
}
}