const Discord = require("discord.js");

module.exports = {
    run: (client, message, args) => {

if (!message.member.hasPermission('MANAGE_CHANNELS')) {
return message.reply("**Você não tem Perm, `F`**").then(f => {
message.delete().catch(O_o => {});
f.react('<a:pressF_cdh:783883742657380372>')
})
}
      if (!args[0])
        return message.channel.send(
          `**Você não especificou o tempo em segundos que deseja definir para o modo lento deste canal!**`
        );
      if (isNaN(args[0])) return message.channel.send(`Isso não é um número!`);
      let reason = message.content.slice(
        client.prefix.length + 9 + args[0].length + 1
      );
      message.channel.setRateLimitPerUser(args[0], reason);
      message.channel.send
let embed = new Discord.MessageEmbed()
.setColor('#00FA9A')
.setTitle('Slow Mode Ativo!')
.setDescription(`Definido para: **${args[0]}** segundo(s)`)
message.delete().catch(O_o => {});
return message.channel.send(message.author, embed)
    },
  };