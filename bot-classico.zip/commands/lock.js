const Discord = require("discord.js");

exports.run = async (client, message, args) => {

      let channel = message.mentions.channels.first() || message.channel;

      if (!message.member.roles.cache.has("800157405584424993")) return message.reply("**Você não tem permissão para isto!**").then(msgd => msgd.delete({timeout: 50000}))

      channel.updateOverwrite(message.guild.id, {
        SEND_MESSAGES: false, reason: `Comando de lock ;)` 
        })

let embed = new Discord.MessageEmbed()
.setTitle('**🔒 Canal bloqueado corretamente!!**')
.setDescription(`**🔨 Moderador:** <@${message.author.id}>\n\n> **O canal ${message.channel} foi trancado com sucesso.**\n\nUse \`lh!unlock\` Para desbloquear ou reaga 🔒`)
.setColor('#00FA9A')
.setThumbnail(message.guild.iconURL({dynamic: true}))
message.delete()


message.channel.send(message.author, embed).then(msg => { //quando enviar a mensagem...
  msg.react("🔒").then(() => { //quando reagir o primeiro emoji...
  })

  const unlock = msg.createReactionCollector((reaction, user) => reaction.emoji.name == `🔒` && user.id == message.author.id, {time: 60000}) //time: tempo, 1000 = 1sec, 10000 = 10sec
  unlock.on(`collect`, r =>{
    channel.updateOverwrite(message.guild.id, {
      SEND_MESSAGES: true, reason: `Comando de lock ;)` 
    })
    let embed = new Discord.MessageEmbed()
    .setDescription(`**O canal ${message.channel} foi desbloqueado com sucesso.**`)
    .setColor(`RANDOM`)
    message.channel.send(message.author, embed).then(msgd => msgd.delete({timeout: 30000}))
      r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
  })
})
}