const Discord = require('discord.js')

module.exports = {
    run: (client, message, args) => {
  let user;
  
  if (message.mentions.users.first()) {
    user = message.mentions.users.first();
  } else if (args[0]) {
    user = message.guild.members.cache.get(args[0]).user;
  } else {
    user = message.author;
  }
  
  let avatar = user.displayAvatarURL({size: 4096, dynamic: true});
  const embed = new Discord.MessageEmbed()
  .setTitle(`Avatar de ${user.username}`)  
  .setDescription(`:frame_photo: **Clique [Aqui](${avatar}) Para Abaixar.**`)
  .setColor("RANDOM")
  .setImage(avatar)
  .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));
  message.delete().catch(O_o => {});
  return message.channel.send(embed);
    }
}