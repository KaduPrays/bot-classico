const Discord = require('discord.js')
const db = require("quick.db")
const fs = require("fs");

exports.run = async (client, message, args) => {

    if (!message.member.roles.cache.has("792125228343885854")) return message.reply("**Você precisa do cargo Registrador, para fazer registros!**").then(msgd => msgd.delete({timeout: 50000}))
    if (!message.mentions.users.first()) return message.reply("**Mencione um usuário!**").then(msgd => msgd.delete({timeout: 50000}))
    let cargos = []
    let pv = []
    let homem = message.guild.roles.cache.get("792125252578705468")
    let mulher = message.guild.roles.cache.get("792125251323428885")
    let nBinário = message.guild.roles.cache.get("792125253639733278")
    let mais18 = message.guild.roles.cache.get("792125255563870239")
    let menos18 = message.guild.roles.cache.get("792125256587280455")
    let hetero = message.guild.roles.cache.get("792125258424778772")
    let lgbt = message.guild.roles.cache.get("792125259477680160")
    let solteiro = message.guild.roles.cache.get("792125261327106060")
    let namorando = message.guild.roles.cache.get("792125264653975573")
    let casado = message.guild.roles.cache.get("792125263721922620")
    let enrolado = message.guild.roles.cache.get("792125262710964224")
    let sudeste = message.guild.roles.cache.get("792125269884272660")
    let norte = message.guild.roles.cache.get("792125266675105813")
    let sul = message.guild.roles.cache.get("792125271037706270")
    let centrooeste = message.guild.roles.cache.get("792125268881047552")
    let nordeste = message.guild.roles.cache.get("792125267752910848")
    let estrangeiro = message.guild.roles.cache.get("792125272152342608")
    let member = message.guild.member(message.mentions.users.first())
    message.delete().catch(O_o => {});
    const rEmbed1 = new Discord.MessageEmbed()
    .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
    .addField("Qual a sua sexualidade?", `<a:LH_1:773710260879228959> ${homem}
<a:LH_2:773710283809882133> ${mulher}
<a:IDM_3:773710305179467816> ${nBinário}`)
    .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", "Nenhum")
    .setColor("RANDOM")
    .setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
    const r1 = await message.channel.send(rEmbed1)
    const emojis = [ "<a:erradocdh:777769043309363241>", "<a:LH_1:773710260879228959>", "<a:LH_2:773710283809882133>", "<a:IDM_3:773710305179467816>", "<a:LH_4:773710347277828166> ", "<a:IDM_5:773710404932075570>", "<a:LH_6:773710505159950376> ", "<:setaCDH:775864281441763388>"]
    for (const i in emojis) {
        await r1.react(emojis[i])
    }
    const filter = (r, u) => r.me && u.equals(message.author),
    collector = r1.createReactionCollector(filter, {max: 1})

    collector.on("collect", (r) => {
        switch (r.emoji.name) {
            case "LH_1": {
                member.roles.add(homem)
                cargos.push(homem)
                pv.push(homem.name)
                r.users.remove(message.author)
                break
            }
            case "LH_2": {
                member.roles.add(mulher)
                cargos.push(mulher)
                pv.push(mulher.name)
                r.users.remove(message.author)
                break
            }
            case "IDM_3": {
                member.roles.add(nBinário)
                cargos.push(nBinário)
                pv.push(nBinário.name)
                r.users.remove(message.author)
                break
            }
            case "setaCDH": {
                r.users.remove(message.author)
                r1.delete()
                if(cargos.length === 0) return message.channel.send("Essa pergunta é obrigatória! Registro cancelado!") 
                break
            }
        }
        const r2Embed = new Discord.MessageEmbed()
        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694>
 Registrado: ${member.user}`)
.addField("Qual sua idade?", `<a:LH_1:773710260879228959> ${mais18}
<a:LH_2:773710283809882133> ${menos18}`)
.addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
.setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
.setColor("RANDOM")
collector.on("end", async c => {
let r2 = await r1.edit(r2Embed)
const collector2 = r2.createReactionCollector(filter, {max: 1})
collector2.on("collect", (u) => {
switch (u.emoji.name) {
    case "LH_1": {
        member.roles.add(mais18)
        cargos.push(mais18)
        pv.push(mais18.name)
        u.users.remove(message.author)
        break
    }
    case "LH_2": {
        member.roles.add(menos18)
        cargos.push(menos18)
        pv.push(menos18.name)
        u.users.remove(message.author)
        break
    }
    case "setaCDH": {
        u.users.remove(message.author)
        r2.delete()
        if (cargos.length == 1) return message.channel.send("Essa pergunta é obrigatória! Registro cancelado!").then(msgd => msgd.delete({timeout: 30000}))
        break
    }
    case "erradocdh": {
        u.users.remove(message.author)
        r2.delete()
        member.roles.remove(homem)
        member.roles.remove(mulher)
        member.roles.remove(nBinário)
        member.roles.remove(mais18)
        member.roles.remove(menos18)
        return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
        break
    }
}
const rEmbed3 = new Discord.MessageEmbed()
.setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
.addField("Qual seu gênero?", `<a:LH_1:773710260879228959> ${hetero}
<a:LH_2:773710283809882133> ${lgbt}`)
.addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
.setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
.setColor("RANDOM")
collector2.on("end", async d => {
    const r3 = await r2.edit(rEmbed3)
    const collector3 = r3.createReactionCollector(filter, {max: 1})
    collector3.on("collect", (a) => {
        switch (a.emoji.name) {
            case "LH_1": {
                member.roles.add(hetero)
                cargos.push(hetero)
                pv.push(hetero.name)
                a.users.remove(message.author)
                break
            }
            case "LH_2": {
                member.roles.add(lgbt)
                cargos.push(lgbt)
                pv.push(lgbt.name)
                a.users.remove(message.author)
                break
            }
            case "setaCDH": {
                a.users.remove(message.author)
                break
            }
            case "erradocdh": {
                a.users.remove(message.author)
                r3.delete()
                member.roles.remove(homem)
                member.roles.remove(mulher)
                member.roles.remove(nBinário)
                member.roles.remove(mais18)
                member.roles.remove(menos18)
                member.roles.remove(hetero)
                member.roles.remove(lgbt)
                member.roles.remove(enrolado)
                member.roles.remove(casado)
                member.roles.remove(solteiro)
                member.roles.remove(namorando)
                return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
                break
       }
    }
        const rEmbed4 = new Discord.MessageEmbed()
        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
        .addField("Qual seu estado civíl?", `<a:LH_1:773710260879228959> ${namorando}
<a:LH_2:773710283809882133> ${solteiro}
<a:IDM_3:773710305179467816> ${casado}
<a:LH_4:773710347277828166>  ${enrolado}`)
        .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
        .setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
        .setColor("RANDOM")
        collector3.on("end", async k => {
            const r4 = await r3.edit(rEmbed4)
            const collector4 = r4.createReactionCollector(filter, {max: 1})
            collector4.on("collect", g => {
                switch (g.emoji.name) {
                    case "LH_1": {
                        member.roles.add(namorando)
                        cargos.push(namorando)
                        pv.push(namorando.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "LH_2": {
                        member.roles.add(solteiro)
                        cargos.push(solteiro)
                        pv.push(solteiro.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "IDM_3": {
                        member.roles.add(casado)
                        cargos.push(casado)
                        pv.push(casado.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "LH_4": {
                        member.roles.add(enrolado)
                        cargos.push(enrolado)
                        pv.push(enrolado.name)
                        g.users.remove(message.author)
                        break
                    }
                    case "setaCDH": {
                        g.users.remove(message.author)
                        break
                    }
                    case "erradocdh": {
                        g.users.remove(message.author)
                        r4.delete()
                        member.roles.remove(homem)
                        member.roles.remove(mulher)
                        member.roles.remove(nBinário)
                        member.roles.remove(mais18)
                        member.roles.remove(menos18)
                        member.roles.remove(hetero)
                        member.roles.remove(lgbt)
                        member.roles.remove(enrolado)
                        member.roles.remove(casado)
                        member.roles.remove(solteiro)
                        member.roles.remove(namorando)
                        return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
                        break
                    }
                }

                const rEmbed5 = new Discord.MessageEmbed()
                .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
                .addField("Qual a sua localização?", `<a:LH_1:773710260879228959> ${norte}
<a:LH_2:773710283809882133> ${nordeste}
<a:IDM_3:773710305179467816> ${centrooeste}
<a:LH_4:773710347277828166> ${sudeste}
<a:IDM_5:773710404932075570> ${sul}
<a:LH_6:773710505159950376> ${estrangeiro}`)
                .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
                .setFooter("Reaga ❌ Para Voltar Fechar esse registro (use apenas se errar).")
                .setColor("RANDOM")
                collector4.on("end", async (a) => {
                    const r5 = await r4.edit(rEmbed5)
                    const collector5 = r5.createReactionCollector(filter, {max: 1})
                    collector5.on("collect", k => {
                        switch (k.emoji.name) {
                            case "LH_1": {
                                member.roles.add(norte)
                                cargos.push(norte)
                                pv.push(norte.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "LH_2": {
                                member.roles.add(nordeste)
                                cargos.push(nordeste)
                                pv.push(nordeste.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "IDM_3": {
                                member.roles.add(centrooeste)
                                cargos.push(centrooeste)
                                pv.push(centrooeste.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "LH_4": {
                                member.roles.add(sudeste)
                                cargos.push(sudeste)
                                pv.push(sudeste.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "IDM_5": {
                                member.roles.add(sul)
                                cargos.push(sul)
                                pv.push(sul.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "LH_6": {
                                member.roles.add(estrangeiro)
                                cargos.push(estrangeiro)
                                pv.push(estrangeiro.name)
                                k.users.remove(message.author)
                                break
                            }
                            case "setaCDH": {
                                k.users.remove(message.author)
                                break
                            }
                            case "erradocdh": {
                                u.users.remove(message.author)
                                r4.delete()
                                member.roles.remove(homem)
                                member.roles.remove(mulher)
                                member.roles.remove(nBinário)
                                member.roles.remove(mais18)
                                member.roles.remove(menos18)
                                member.roles.remove(hetero)
                                member.roles.remove(lgbt)
                                member.roles.remove(enrolado)
                                member.roles.remove(casado)
                                member.roles.remove(solteiro)
                                member.roles.remove(namorando)
                                member.roles.remove(norte)
                                member.roles.remove(nordeste)
                                member.roles.remove(centrooeste)
                                member.roles.remove(sudeste)
                                member.roles.remove(sul)
                                member.roles.remove(estrangeiro)
                                return message.channel.send("Você Cancelou o Registro.").then(msgd => msgd.delete({timeout: 30000}))
                                break
                        }
                        }
                        const embed = new Discord.MessageEmbed()
                        .setTitle(`${member.user.tag} foi registrado!`)
                        .setThumbnail(message.guild.iconURL({dynamic: true}))
                        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
                        .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", pv.join(", "))
                        .setColor("RANDOM")
                        .setFooter(`ID: ${message.author.id}`)
                        .setTimestamp()
                        const embed2 = new Discord.MessageEmbed()
                        .setTitle("Registro efetuado!")
                        .setColor("RANDOM")
                        .setDescription(`<:listaCDH:775865183293145098> Registrador: ${message.author}
<:pessoaCDH:775865182982897694> Registrado: ${member.user}`)
                        .addField("<:adicionadoCDH:775865180730294324> Cargos recebidos", cargos.join(", "))
                        .setThumbnail(message.guild.iconURL({dynamic: true}))
                        .setFooter(`${message.author.tag} já fez ${(db.fetch(`registros_${message.author.id}`) + 1).toLocaleString()} registros!`)
                        collector5.on("end", async feijoada => {
                            let msg = await r5.edit(embed2)
                            client.channels.cache.get("792125345175306261").send(embed2)
                            db.add(`registros_${message.author.id}`, 1)
                            msg.delete({timeout: 10000})
                            member.roles.remove("792125278389928007")
                            member.roles.add("792125279786762240")
                            member.user.send(embed)
                            message.channel.messages.fetch({limit: 50}).then(messages => {
                                message.channel.bulkDelete(messages.filter(msg => msg.author.id == member.user.id))
                            })
                        })
                    })
                })
            })
        })
    })
})
})
})
})
}