const Discord = require("discord.js")
const fs = require("fs")
var cor = "RANDOM"
const db = require("quick.db")

module.exports.run = async (client, message, args) => {

        let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author
        let member = message.guild.member(user)

        let erro1 = new Discord.MessageEmbed()
        .setColor(cor)
        .setDescription("<a:Not:770666678283141170> O usuário não e um staff de **Mov-Call**, no entando eu não possuo os Registros recentes/anteriores de Chamadas no Servidor!")
        if (!member.roles.cache.has("792125232089530400")) return message.reply(erro1).then(m => m.delete({timeout: 15000}))

        let segundos = db.fetch(`s_${member.id}`)
        let minutos = db.fetch(`m_${member.id}`)
        let horas = db.fetch(`h_${member.id}`)
        if (!segundos) segundos = 0
        if (!minutos) minutos = 0
        if (!horas) horas = 0

        var tempp = `**${horas}** Horas,**${minutos}** Minutos e **${segundos}** Segundos!`
        let embed = new Discord.MessageEmbed()
        .setAuthor(`${message.guild.name} - Tempo em Call`, message.guild.iconURL())
        .setTitle(`**Membro: ${user.tag}**`)
        .addField("<:dkvoice:799817353327018054> Tempo Salvo:", tempp)
        .setColor(cor)
        .setFooter(`${message.guild.name}`, message.guild.iconURL())
        .setTimestamp()
        return message.channel.send(embed)
}