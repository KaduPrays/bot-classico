const Discord = require("discord.js");

module.exports.run = async (client, message) => {
    if (!message.member.roles.cache.has("792125232089530400")) return message.reply("**Você precisa ser da equipe de div.**").then(msgd => msgd.delete({timeout: 50000}))
    message.delete().catch(O_o => {})

    let tm = message.guild.memberCount;
    
    var user = message.mentions.users.first();

    if (!user) user = message.author;

    var targetInvites = await message.guild.fetchInvites();

    var invitesUses = 0;

    targetInvites.forEach(invite => {
        if (invite.inviter.id === user.id) {
            invitesUses += invite.uses;
          }
    });
    let embed = new Discord.MessageEmbed()
    .setTitle(`<a:LHtnkstaff:766049083311259648> • Divulgações: ${user.tag}\n`)
    .setDescription(`<:link1:798734256184492033> **• Convidados:**\n\`${invitesUses}\`\n<:Members:811411897664536576> • **Total no servidor:**\n\`${tm}\``)
    .setColor('#ff0000')
    .setFooter("Para ver suas divs use | lh!divs")
    .setTimestamp();
    message.delete().catch(O_o => {});

    message.reply(embed).then(msg => msg.delete(25000));
};
module.exports.help = {
    name: "divulgador"
}