const Discord = require("discord.js");

exports.run = async (client, message, args) => {
    
if (!message.member.hasPermission('BAN_MEMBERS')) return message.reply('❌ Não tens permissão para ver a lista de membros banidos!').then(msgd => msgd.delete({timeout: 20000}))
message.delete().catch(O_o => {}); //Verifica se quem enviou o comando tem permissão para ver os membros banidos
if (!message.guild.me.hasPermission('BAN_MEMBERS')) return message.channel.send('❌ Não tenho permissão para ver a lista de membros banidos!').then(msgd => msgd.delete({timeout: 20000}))
message.delete().catch(O_o => {}); //Verifica se o bot tem permissão para ver os membros banidos

const bans = await message.guild.fetchBans(); //Obtém a lista de membros banidos do servidor

if (!bans.first()) //Se a lista estiver vazia retorna
    return message.channel.send('❌ Este servidor não tem membros banidos!').then(msgd => msgd.delete({timeout: 20000}))
    message.delete().catch(O_o => {});
   
let msg = '';

//Mapeia a lista de membros banidos e adiciona a sua tag à variável msg (USER#0001)
bans.map(user => {
    msg += `\`${user.user.tag}\`, `;
});

//Por fim envia a mensagem com todas as tags dos membros banidos, com split no caso de o servidor ter muitos membros banidos e a lista for grande
let embed = new Discord.MessageEmbed()
.setDescription('__📑 **Lista de membros banidos:**__\n\n' + msg, { split: true })
.setColor("RANDOM")
message.delete().catch(O_o => {});
message.channel.send(embed).then(msgd => msgd.delete({timeout: 50000}))
}