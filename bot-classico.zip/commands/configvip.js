const Discord = require("discord.js")
const db = require("quick.db")

exports.run = async (client, message, args) => {
    let member = message.mentions.users.first() || client.users.cache.find(membro1 => membro1.id === args[0]) || client.users.cache.find(membro1 => membro1.username === args[0]) || client.users.cache.find(membro1 => membro1.tag === args[0])
    if (!message.member.hasPermission('MANAGE_ROLES')) {
        return message.reply("**Você não tem Permissão**")
    }
    
            if(!member) {
            return message.reply("**Por favor mencione um usuário válido!**")
            }

if (member) {
    let filter = m => m.author.id === message.author.id
    let embed = new Discord.MessageEmbed()
    .setColor(`#ff00ff`)
    .setTitle(`<:LH_Vstaff:798004368040788008> • Interface para configuração de VIP - ${message.member.guild.name}`)
    .setDescription(`
    **Informações:**
    <:l_setaroxa:798003915403558933> • **Usuário Selecionado:** <@${member.id}>
    <:l_setaroxa:798003915403558933> • **Tag Vinculada:** ${db.get(`Tag_${member.id}`) || "Nenhum"}
    <:l_setaroxa:798003915403558933> • **Canal Vinculado:** ${db.get(`Canal_${member.id}`) || "Nenhum"}

    **Configurações Disponiveis:**
    <a:1l:792886718353244170> • Vincular uma tag ao usuário
    <a:2l:792886988012257322> • Vincular um canal ao usuário
    <a:3l:792887672448221226> • Desvincular tag e canal do usuário
    <a:4l:792891959798005770> • Excluir tag e canal vinculados ao usuário
    `)
    
    message.channel.send(message.author, embed).then(msg => { //quando enviar a mensagem...
        let emoji1 = client.emojis.cache.get('798004368040788008')
        msg.react(emoji1).then(() => { //quando reagir o primeiro emoji...
            let emoji2 = client.emojis.cache.get('792886718353244170')
               msg.react(emoji2);
               let emoji3 = client.emojis.cache.get('792886988012257322')
               msg.react(emoji3);
               let emoji4 = client.emojis.cache.get('792887672448221226')
               msg.react(emoji4)
               let emoji5 = client.emojis.cache.get('792891959798005770')
               msg.react(emoji5)
               })
       
       
               const vip1 = msg.createReactionCollector((reaction, user) => reaction.emoji.id == "792886718353244170" && user.id == message.author.id, {time: 60000}) //time: tempo, 1000 = 1sec, 10000 = 10sec
               const voltar = msg.createReactionCollector((reaction, user) => reaction.emoji.name == "798004368040788008" && user.id == message.author.id, {time: 60000})
               const vip2 = msg.createReactionCollector((reaction, user) => reaction.emoji.id == "792886988012257322" && user.id == message.author.id, {time: 60000})
               const vip3 = msg.createReactionCollector((reaction, user) => reaction.emoji.id == "792887672448221226" && user.id == message.author.id, {time: 60000})
               const vip4 = msg.createReactionCollector((reaction, user) => reaction.emoji.id == "792891959798005770" && user.id == message.author.id, {time: 60000})
               vip1.on(`collect`, r =>{

                let embed = new Discord.MessageEmbed()
                .setDescription(`<:Canais:798007026214240296> • **Mencione ou utilize um ID de uma tag a ser vinculada com o usuário.**`)
                .setColor(`#ff00ff`)
                message.channel.send(embed).then(msgd => msgd.delete({timeout: 50000}))

    r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
     message.channel.awaitMessages(filter, {
        max: 1,
        time: 20000,
        errors: ["time"]
      }).then(message => {
          message = message.first()
          if (!message.mentions.roles.first() || message.guild.roles.cache.get(message.content)) {
              message.reply('Erro')
          }
          if (message.mentions.roles.first() || message.guild.roles.cache.get(message.content)) {
            let tag = message.mentions.roles.first() || message.guild.roles.cache.get(message)
            message.reply('Sucesso!')
            db.set(`Tag_${member.id}`, `<@&${tag.id}>`)
            db.set(`TagID_${member.id}`, tag.id)
        }
    })
        })
        voltar.on(`collect`, r =>{ //quando coletar
            let embed_three = new Discord.MessageEmbed()
            .setColor(`#ff00ff`)
            .setTitle(`<:LH_Vstaff:798004368040788008> • Interface para configuração de VIP - ${message.member.guild.name}`)
            .setDescription(`
            **Informações:**
            <:l_setaroxa:798003915403558933> • **Usuário Selecionado:** <@${member.id}>
            <:l_setaroxa:798003915403558933> • **Tag Vinculada:** ${db.get(`Tag_${member.id}`) || "Nenhum"}
            <:l_setaroxa:798003915403558933> • **Canal Vinculado:** ${db.get(`Canal_${member.id}`) || "Nenhum"}
        
            **Configurações Disponiveis:**
            <a:1l:792886718353244170> • Vincular uma tag ao usuário
            <a:2l:792886988012257322> • Vincular um canal ao usuário
            <a:3l:792887672448221226> • Desvincular tag e canal do usuário
            <a:4l:792891959798005770> • Excluir tag e canal vinculados ao usuário
            `)
    msg.edit(embed_three)
    r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
        })
        vip2.on(`collect`, r =>{

            let embed = new Discord.MessageEmbed()
            .setDescription(`<:Canais:798007026214240296> • **Escreva o id ou nome de um canal que deseja vincular ao usuário.**`)
            .setColor(`#ff00ff`)
            message.channel.send(embed).then(msgd => msgd.delete({timeout: 50000}))

            r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
             message.channel.awaitMessages(filter, {
                max: 1,
                time: 20000,
                errors: ["time"]
              }).then(message => {
                  message = message.first()
                  if (!client.channels.cache.get(message.content)) {
                      message.reply('Erro').then(msgd => msgd.delete({timeout: 30000}))
                  }
                  if (client.channels.cache.get(message.content)) {
                    let canal = client.channels.cache.get(message.content)
                    message.reply('Sucesso!').then(msgd => msgd.delete({timeout: 30000}))
                    db.set(`Canal_${member.id}`, canal.name)
                    db.set(`CanalID_${member.id}`, canal.id)
                }
              })
    })
    vip3.on(`collect`, r =>{
        r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
        db.delete(`Tag_${member.id}`)
        db.delete(`Canal_${member.id}`)
        message.reply('Tag e canal do usuário ' + member.tag + " foram desvinculados")
})

    vip4.on(`collect`, r =>{
        r.users.remove(message.author.id) //isso irá remover as reações de quem chamou o comando
        let tag = db.get(`TagID_${member.id}`)
        let canal = db.get(`CanalID_${member.id}`)
        let tdelete = message.guild.roles.cache.find(tag)
        let cdelete = message.guild.channels.cache.find(canal)
        cdelete.delete()
        tdelete.delete()
        db.delete(`Tag_${member.id}`)
        db.delete(`Canal_${member.id}`)
       
        message.reply('Tag e canal do usuário ' + member.tag + " foram deletados")
})
})
}
}
exports.config = {
    name: "configvip",
    aliases: ["cv"],
    usage: "<@membro>",
    categoria: "Server",
    desc: "Configura o sistema de vip no servidor"
}