﻿const Discord = require("discord.js");

exports.run = async (client, message, args) => {

    var list = [
        "https://i.imgur.com/CeXp3VO.gif",
        "https://i.imgur.com/gyvOopT.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802035351644405770/tenor_2.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802035351488299048/mlaWAO.gif",
        "https://cdn.discordapp.com/attachments/798787679000985692/802035353534988288/tenor_1.gif"
        
    ];

    var rand = list[Math.floor(Math.random() * list.length)];
    let user = message.mentions.users.first() ||
    client.users.cache.get(args[0]);
    if (!user) {
        return message.reply("Mencione um usuário válido.");
    }
    let avatar = message.author.displayAvatarURL({format: 'png'});
    const slap = new Discord.MessageEmbed()
    .setColor("#FF0000")
    .setDescription(`<:bravoCDH:779872009722527764> ${message.author} **deu um Tapa em** ${user}`)
    .setImage(rand)
    .setTimestamp()
    .setFooter(`ID: ${message.author.id}`)
    .setAuthor(message.author.tag, avatar);
    await message.channel.send(slap);
}