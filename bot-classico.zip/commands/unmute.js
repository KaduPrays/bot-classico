const Discord = require("discord.js")

module.exports=  {
    name : 'unmute', 
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
        if (!message.member.roles.cache.has("800157405584424993")) return message.reply("**Você não tem permissão.**").then(msgd => msgd.delete({timeout: 50000}))
        const Member = message.mentions.members.first() || message.guild.members.cache.get(args[0])

        if(!Member) return message.channel.send('Membro não encontrado')
        let rasao = args.slice(1).join(' ')
        if(!rasao) rasao = "Nenhuma rasão foi dita."

        const role = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'mutado');

        await Member.roles.remove(role)
        let embed = new Discord.MessageEmbed()
        .setTitle(`<:Aviso:813596006541295636> Ação | Mute`, message.guild.iconURL())
         .setDescription(`<a:Seta:813594852926947329> **•** <@${Member.id}> foi desmutado.
  <:Folha:813593246043078678> **• Motivo:** ${rasao}`)
        .setColor("RANDOM")
        .setTimestamp()
        message.channel.send(embed).then(msgd => msgd.delete({timeout: 30000}))
        let embedlog = new Discord.MessageEmbed()
        .setTitle(`<:Aviso:813596006541295636> **Um usuário foi desmutado!**`, message.guild.iconURL())
         .setDescription(`
<:mod:813592586450894849>** Moderador:**
 **•** ${message.author}
<:Members:813592452664786994> **Usuário:**
 **•** ${Member.user}
<:Folha:813593246043078678> **• Motivo:** ${rasao}`)
        .setColor("RANDOM")
        .setTimestamp()
        client.channels.cache.get("813611973228494850").send(embedlog)
    }
}