const Discord = require("discord.js");

exports.run = async (client, message, args) => {

      let channel = message.mentions.channels.first() || message.channel;

      if (!message.member.roles.cache.has("800157405584424993")) return message.reply("**Você não tem permissão para isto!**").then(msgd => msgd.delete({timeout: 50000}))

                channel.updateOverwrite(message.guild.id, {
                  SEND_MESSAGES: true, reason: `Comando de lock ;)` 
                  })

let embed = new Discord.MessageEmbed()
.setTitle('**🔒 Canal desbloqueado corretamente!!**')
.setDescription(`**🔨 Moderador:** <@${message.author.id}>\n\n> **O canal ${message.channel} foi desbloqueado com sucesso.**`)
.setColor('RANDOM')
.setThumbnail(message.guild.iconURL({dynamic: true}))
.setFooter(`ID: ${message.author.id}`)
message.channel.send(message.author, embed)
message.delete()
}