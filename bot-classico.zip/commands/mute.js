const {Message, MessageEmbed}= require('discord.js')
const ms = require('ms')

module.exports = {
    name : 'tempmute',
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
        if (!message.member.roles.cache.has("800157405584424993")) return message.reply("**Você não tem permissão.**").then(msgd => msgd.delete({timeout: 50000}))
        const Member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        const time = args[1]
        if(!Member) return message.channel.send('Membro não encontrado.')
        if(!time) return message.channel.send('Especifique um horário.')
        let rasao = args.slice(2).join(' ')
        if(!rasao) rasao = "Nenhum Motivo Especificado"
        message.delete().catch(O_o => {});
        const role = message.guild.roles.cache.find(role => role.name.toLowerCase() === "mutado")
        if(!role) {
            try {
                const m = await message.channel.send("Criando o cargo..");
                let muterole = await message.guild.roles.create({
                    data : {
                        name : 'mutado',
                        color: "#ff0000",
                        permissions: []
                    }
                });
                message.guild.channels.cache.filter(c => c.type === 'text').forEach(async (channel, id) => {
                    await channel.createOverwrite(muterole, {
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false
                        
                    })
                });
                m.edit(`O cargo foi criado com sucesso.`).then(msgd => msgd.delete({timeout: 30000}))
            } catch (error) {
                console.log(error)
            }
        };
        let role2 = message.guild.roles.cache.find(r => r.name.toLowerCase() === `mutado`)
        if(Member.roles.cache.has(role2.id)) return message.channel.send(`${Member.displayName} Já está silenciado.`)
        await Member.roles.add(role2)
        let embed = new MessageEmbed()
        .setTitle(`**<:Aviso:813596006541295636> Love House | Mute**`, message.guild.iconURL())
         .setDescription(`<a:Seta:813594852926947329> **• Usuário mutado:**
    <:Members:811411897664536576> **• Tag:** \`${Member.user.tag}\`
    <:ServidorID:813593778832408606> **• ID:** \`${Member.id}\`

<a:Seta:813594852926947329> **• Mutado pelo moderador:**
    <:mod:813592586450894849> **• Tag:** \`${message.author.tag}\`
    <:ServidorID:813593778832408606> **• ID:** \`${message.id}\`

  <:rlg:795876185770950698> **• Tempo Mutado:** ${time}

  <:Folha:813593246043078678> **Motivo:** ${rasao}`)
        .setColor("RANDOM")
        .setThumbnail(message.guild.iconURL({dynamic: true}))
        .setFooter(`${message.guild.name}`, message.guild.iconURL())
        .setTimestamp()
        message.channel.send(embed).then(msgd => msgd.delete({timeout: 30000}))
     client.channels.cache.get("813611940001349663").send(embed)

        setTimeout(async () => {
            await Member.roles.remove(role2)
            let embedd = new MessageEmbed()
            .setTitle(`<:Aviso:813596006541295636> Ação | Mute`, message.guild.iconURL())
             .setDescription(`<a:Seta:813594852926947329> **• Usuário desmutado:**
      <:Members:811411897664536576> **•** \`${Member.user.tag}\`
    
      <:Folha:813593246043078678> **• Motivo:** Tempo de mute expirou.`)
            .setColor("RANDOM")
            .setTimestamp()
            message.channel.send(embedd).then(msgd => msgd.delete({timeout: 30000}))
            client.channels.cache.get("813611940001349663").send(embedd)
        }, ms(time))
    }
}