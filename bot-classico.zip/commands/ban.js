const Discord = require('discord.js')
const db = require("quick.db")

module.exports.run = async (client, message, args) => {
    if (!message.member.roles.cache.has("792125193769582612")) return message.reply("Você não tem permisão").then(msgd => msgd.delete({timeout: 10000}))
  message.delete().catch(O_o => {});
    let member = message.mentions.members.first()
    if(!member) return message.reply("**Por favor mencione um usuário válido !**")
  message.delete().catch(O_o => {});
    if(!member.kickable) return message.reply("**Eu não posso banir esse usuário, ele possuí algum cargo maior que o meu.**")
  message.delete().catch(O_o => {});
    let reason = args.slice(1).join(' ')
    if(!reason) reason = "Nenhum Motivo Especificado"
let avatar = member.user.avatarURL({ dynamic: true, format: 'png', size: 2048 });
      const pEmbed = new Discord.MessageEmbed()
          .setDescription(`🛡️ **Moderador:**
${message.author.tag} 
          
👤 **Usuário:**
${member.user.tag}
          
🆔 **ID do usuário:**
${member.user.id}
          
📑 **Motivo:**
${reason}`)
          .setFooter(` ${message.author.tag} já baniu ${(db.fetch(`ban_${message.author.id}`) + 1).toLocaleString()} usuários`)
          .setColor("RANDOM")
          .setTimestamp()
          .setThumbnail(avatar)

    let embed = new Discord.MessageEmbed()
           .setDescription(`**<@${message.author.id}>\nVocê realmente deseja banir**
           
           👤 **Usuário(a):** 
           <@${member.user.id}>
           
           📔 **Motivo:**
           ${reason}`)
           .setColor('RED')

return message.channel.send(embed).then(msg => {
        msg.react('✅');
        msg.react('❌');
        const FilterYes = (reaction, user) => {
            return reaction.emoji.name === '✅' && user.id === message.author.id;
        };
        
        const CollectorYes = msg.createReactionCollector(FilterYes, { time: 60000, max: 1 });
        
        CollectorYes.on('collect', (reaction, user) => {
            let avatar = member.user.avatarURL({ dynamic: true, format: 'png', size: 2048 });
            let embed = new Discord.MessageEmbed()
            .setTitle('__Você foi banido em Love House!__')
            .setDescription(`🛡️ **Moderador:**
${message.author.tag} 
            
👤 **Usuário:**
${member.user.tag}
            
🆔 **ID do usuário:**
${member.user.id}
            
📑 **Motivo:**
${reason}`)
                      .setColor("RANDOM")
                      .setTimestamp()
                      .setThumbnail(avatar)
            member.send(embed)
           let avatar2 = member.user.avatarURL({ dynamic: true, format: 'png', size: 2048 });
           let embed2 = new Discord.MessageEmbed()
            .setTitle("Logs De Ban!!")
            .setColor("RANDOM")
            .setDescription(`__**Informações do banimento:**__

            🛡️ **Moderador:**
            ${message.author.tag} 
            
            👤 **Usuário:**
            ${member.user.tag}
            
            🆔 **ID do usuário:**
            ${member.user.id}
            
            📑 **Motivo:**
            ${reason}`)
            .setThumbnail(avatar2)
            .setTimestamp()
                client.channels.cache.get("794026498675179570").send(embed2)
            member.ban({ reason: `${reason}` })
            message.channel.send(pEmbed).then(msgd => msgd.delete({timeout: 30000}))
            msg.delete()
         })

            const FilterCancel = (reaction, user) => {
                return reaction.emoji.name === '❌' && user.id === message.author.id;
            };


                const CollectorCancel = msg.createReactionCollector(FilterCancel, { time: 60000, max: 1 });
                CollectorCancel.on('collect', (reaction, user) => {
                    message.channel.send('**O Comando Foi Cancelado.**').then(msgd => msgd.delete({timeout: 10000}))
                    msg.delete()
   })
 })

    client.on('message', function(msg) {
        if (msg.content.startsWith(config.prefix) || !msg.author.bot) {
            const user = msg.member;
            const args = msg.content.slice(config.prefix.length).trim().split(' ');
            const command = args.shift();
            var mentionedUser = msg.mentions.members.first();
            if (command === 'ban' && user.hasPermission('BAN_MEMBERS')) {
                mentionedUser.ban(args.join()).then(function() {
                    msg.reply(mentionedUser.toString() + ' banido com sucesso!');
                }).catch(function(e) {
                    msg.reply('Não foi possível banir ' + mentionedUser.toString() + ' devido ao seguinte erro: ' + e);
                });
            }
        }
    });

}