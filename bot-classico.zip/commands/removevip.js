const db = require('quick.db')
const { MessageEmbed } = require('discord.js')

exports.config = {
    name: "addvip",
    aliases: ["av"],
    usage: "<@membro>",
    categoria: "Server",
    desc: "Adicione vip a algum usuário"
}
exports.run = async (client, message, args) => {
    let member = message.mentions.members.first() || client.users.cache.get(args[0]);
 if (!member) {
          return message.reply('Você precisa marcar alguém.');
    }
    message.delete().catch(O_o => {});
    if (db.get(`Vip_${member.id}`) === 'Vip') {

    }            
        let cargo = await message.guild.roles.cache.find(x => x.id === db.get(`TagID_${message.author.id}`))

                if (cargo) {
                    message.guild.members.cache.get(member.id).roles.remove(cargo)
                    let avatar = message.author.avatarURL({ dynamic: true, format: 'png', size: 2048 });
                    let embed = new MessageEmbed()
                    .setColor("RANDOM")
                    .setTitle(`Gerenciamento de VIP - ${message.member.guild.name}`)
                    .setDescription(`
<:pessoaCDH:775865182982897694> **• Usuário:**
 ${member} 
 <:l_setaroxa:798003915403558933> **• Representante:**
 ${message.author}
 <:l_setaroxa:798003915403558933> **• Tag Removida:**
 ${cargo}
                    `)
                   .setThumbnail(avatar)
                   message.reply(embed).then(msgd => msgd.delete({timeout: 30000}))
                }
            }